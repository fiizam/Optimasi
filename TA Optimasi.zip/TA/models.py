import sqlite3

def init_db():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    # Tabel admin login
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    email TEXT UNIQUE,
                    password TEXT,
                    name TEXT
                )''')
    c.execute("INSERT OR IGNORE INTO users (email, password, name) VALUES (?, ?, ?)",
              ('admin@gmail.com', 'admin123', 'Fii'))

    # Tabel Dokter
    c.execute('''CREATE TABLE IF NOT EXISTS dokter (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama TEXT,
    spesialis TEXT,
    unit_id INTEGER
)''')


    # Tabel Unit Instalasi
    c.execute('''CREATE TABLE IF NOT EXISTS unit (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nama TEXT
                )''')

    # Tabel Shift
    c.execute('''CREATE TABLE IF NOT EXISTS shift (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    kode TEXT,
                    jam_mulai TEXT,
                    jam_selesai TEXT
                )''')

    conn.commit()
    conn.close()

def get_user(email, password):
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE email=? AND password=?", (email, password))
    user = c.fetchone()
    conn.close()
    return user
