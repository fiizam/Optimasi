from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3
from models import init_db, get_user
from calendar import monthrange
import datetime

app = Flask(__name__)
app.secret_key = 'rahasia_super_secret_key'

# ----------------- LOGIN ------------------
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = get_user(request.form['email'], request.form['password'])
        if user:
            session['user'] = user['name']
            return redirect(url_for('dashboard'))
        else:
            return render_template('login.html', error='Login gagal')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect('/')

# ----------------- DASHBOARD ------------------
@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    # Hitung total dokter
    c.execute("SELECT COUNT(*) as total FROM dokter")
    total_dokter = c.fetchone()["total"]

    # Hitung total unit instalasi
    c.execute("SELECT COUNT(*) as total FROM unit")
    total_unit = c.fetchone()["total"]

    # Hitung total shift
    c.execute("SELECT COUNT(*) as total FROM shift")
    total_shift = c.fetchone()["total"]

    # Hitung total spesialis unik
    c.execute("SELECT COUNT(DISTINCT spesialis) as total FROM dokter WHERE spesialis IS NOT NULL")
    total_spesialis = c.fetchone()["total"]

    conn.close()

    return render_template(
        'dashboard.html',
        total_dokter=total_dokter,
        total_unit=total_unit,
        total_shift=total_shift,
        total_spesialis=total_spesialis,
        total_jadwal="1 Jadwal Berdasarkan Bulan"  # kamu bisa buat ini dinamis juga nanti
    )


# ----------------- CRUD DOKTER ------------------
@app.route('/dokter', methods=['GET', 'POST'])
def dokter():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    # Ambil daftar unit
    c.execute("SELECT * FROM unit")
    unit = c.fetchall()

    if request.method == 'POST':
        nama = request.form['nama']
        spesialis = request.form['spesialis']
        unit_id = request.form['unit_id']
        c.execute("INSERT INTO dokter (nama, spesialis, unit_id) VALUES (?, ?, ?)",
                  (nama, spesialis, unit_id))
        conn.commit()

    # JOIN agar bisa tampilkan nama unit di tabel
    c.execute("SELECT dokter.id, dokter.nama, dokter.spesialis, unit.nama AS unit_nama FROM dokter LEFT JOIN unit ON dokter.unit_id = unit.id")
    data = c.fetchall()
    conn.close()
    return render_template("dokter.html", dokter=data, unit=unit)

@app.route('/hapus_dokter/<int:id>')
def hapus_dokter(id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("DELETE FROM dokter WHERE id=?", (id,))
    conn.commit()
    conn.close()
    return redirect('/dokter')

# ----------------- CRUD UNIT INSTALASI ------------------
@app.route('/unit', methods=['GET', 'POST'])
def unit():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    if request.method == 'POST':
        nama = request.form['nama']
        c.execute("INSERT INTO unit (nama) VALUES (?)", (nama,))
        conn.commit()
    c.execute("SELECT * FROM unit")
    data = c.fetchall()
    conn.close()
    return render_template("unit.html", unit=data)

@app.route('/hapus_unit/<int:id>')
def hapus_unit(id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("DELETE FROM unit WHERE id=?", (id,))
    conn.commit()
    conn.close()
    return redirect('/unit')

# ----------------- CRUD SHIFT ------------------
@app.route('/shift', methods=['GET', 'POST'])
def shift():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    if request.method == 'POST':
        kode = request.form['kode']
        mulai = request.form['mulai']
        selesai = request.form['selesai']
        c.execute("INSERT INTO shift (kode, jam_mulai, jam_selesai) VALUES (?, ?, ?)", (kode, mulai, selesai))
        conn.commit()
    c.execute("SELECT * FROM shift")
    data = c.fetchall()
    conn.close()
    return render_template("shift.html", shift=data)

@app.route('/hapus_shift/<int:id>')
def hapus_shift(id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("DELETE FROM shift WHERE id=?", (id,))
    conn.commit()
    conn.close()
    return redirect('/shift')

# ----------------- JADWAL OTOMATIS (Greedy) ------------------
@app.route('/jadwal', methods=['GET', 'POST'])
def jadwal():
    hasil = {}
    jadwal_data = []

    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    # Ambil semua unit
    c.execute("SELECT * FROM unit")
    unit = c.fetchall()

    if request.method == 'POST':
        bulan = int(request.form['bulan'])
        tahun = int(request.form['tahun'])
        id_unit = int(request.form['unit'])

        # Ambil dokter sesuai unit
        c.execute("SELECT nama FROM dokter WHERE unit_id = ?", (id_unit,))
        dokter_list = [row["nama"] for row in c.fetchall()]
        total_dokter = len(dokter_list)

        if total_dokter == 0:
            hasil = {
                'bulan': bulan,
                'tahun': tahun,
                'nama_unit': next((u['nama'] for u in unit if u['id'] == id_unit), "Unit Tidak Ditemukan"),
                'pesan': "Tidak ada dokter yang tersedia untuk unit ini."
            }
            conn.close()
            return render_template("jadwal.html", unit=unit, hasil=hasil, jadwal=[])

        # Hitung jumlah hari & shift
        jumlah_hari = monthrange(tahun, bulan)[1]
        total_minggu = sum(1 for i in range(1, jumlah_hari + 1)
                           if datetime.date(tahun, bulan, i).weekday() == 6)
        total_nonminggu = jumlah_hari - total_minggu
        total_shift = total_nonminggu * 2 + total_minggu * 3

        hasil = {
            'bulan': bulan,
            'tahun': tahun,
            'nama_unit': next((u['nama'] for u in unit if u['id'] == id_unit), "Unit Tidak Ditemukan"),
            'hari': jumlah_hari,
            'minggu': total_minggu,
            'nonminggu': total_nonminggu,
            'total_shift': total_shift,
            'total_dokter': total_dokter
        }

        # Penjadwalan otomatis (greedy)
        shift_harian = {}
        idx = 0

        for i in range(1, jumlah_hari + 1):
            tgl = datetime.date(tahun, bulan, i)
            is_minggu = tgl.weekday() == 6
            tanggal_str = f"{tgl.strftime('%A')}, {tgl.day}/{tgl.month}/{tgl.year}"

            shift_harian[tanggal_str] = {}
            shift_count = 3 if is_minggu else 2
            used_today = set()

            for shift in range(shift_count):
                shift_label = ["Pagi", "Siang", "Malam"][shift]
                available = [d for d in dokter_list if d not in used_today]
                if not available:
                    available = dokter_list  # reset jika habis

                chosen = available[idx % len(available)]
                shift_harian[tanggal_str][shift_label] = chosen
                used_today.add(chosen)
                idx += 1

        # Buat data tampil di tabel
        no = 1
        for tgl, shifts in shift_harian.items():
            jadwal_data.append({
                'no': no,
                'tanggal': tgl,
                'pagi': shifts.get("Pagi", "-"),
                'siang': shifts.get("Siang", "-"),
                'malam': shifts.get("Malam", "-")
            })
            no += 1

    conn.close()
    return render_template("jadwal.html", unit=unit, hasil=hasil, jadwal=jadwal_data)


# ----------------- MAIN ------------------
if __name__ == '__main__':
    init_db()
    app.run(debug=True)
